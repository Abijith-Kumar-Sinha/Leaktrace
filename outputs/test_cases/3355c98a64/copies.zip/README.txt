LeakTrace case 3355c98a64
One PDF per centre. Keep master_UNMARKED_keep_secret.pdf and the secret key private.
LeakTrace is an INVESTIGATIVE-LEAD tool. A match shows which centre's printed copy the photographed paper most probably came from; it does not prove who leaked it, and a retyped paper carries no fingerprint.
